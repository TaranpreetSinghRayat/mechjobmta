
function askOnEnter ( theVehicle, seat, jacked )
	if (getVehicleType(theVehicle) == "Automobile") or (getVehicleType(theVehicle) == "Helicopter") or (getVehicleType(theVehicle) == "Monster Truck") then
		if (getTeamName(getPlayerTeam( source )) == "Civilian")--[[ and classes[getElementData(source, "class")]] then
			if seat == 1 then
					local theUser = getVehicleOccupant ( theVehicle, 0 )
					if isElement(theUser) then
						triggerClientEvent ( theUser, "onMechanicShowGUI", getRootElement(), source,theVehicle)
						outputChatBox ("Waiting till player has made a choise...", source, 0, 225, 0)
					end
			end
		end
	end
end
addEventHandler ( "onPlayerVehicleEnter", getRootElement(), askOnEnter )

function rejectMechanicRequest (theMechanic)
	outputChatBox( " " .. getPlayerName(source) .. " dont want a car fix.",theMechanic, 200, 0, 0)
end
addEvent("rejectMechanicRequest", true)
addEventHandler("rejectMechanicRequest", root, rejectMechanicRequest)

function doVehicleRepair (option, mechanic, vehicle)
	if (option == "option1") then
		if ( source == mechanic ) then
			if getPlayerMoney(source) > 600 then
				addVehicleUpgrade ( vehicle, 1008 )
				takePlayerMoney ( source, 600 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You bought nitro for your own vehicle, you paid 60% of the price. ($600)", source, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		else
			if getPlayerMoney(source) > 1008 then
				addVehicleUpgrade ( vehicle, 1008 )
				takePlayerMoney ( source, 1000 )
				givePlayerMoney ( mechanic, 1000 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You bough 5 nitros for your vehicle you paid $1000 by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
				outputChatBox("".. getPlayerName(source) .." bought nitro for his vehicle, you earned $1000", mechanic, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		end
	elseif (option == "option2") then
	local wheel1, wheel2, wheel3, wheel4 = getVehicleWheelStates ( vehicle )
	if ( wheel1 == 1 ) or ( wheel2 == 1 ) or ( wheel3 == 1 ) or ( wheel4 == 1 ) then
		if ( source == mechanic ) then
			if getPlayerMoney(source) > 75 then
				setVehicleWheelStates ( vehicle, 0, 0, 0, 0 )
				takePlayerMoney ( source, 75 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("You repaired the wheels of your vehicle, you paid 50% of the price. ($75)", source, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		else
			if getPlayerMoney(source) > 150 then
				setVehicleWheelStates ( vehicle, 0, 0, 0, 0 )
				takePlayerMoney ( source, 150 )
				givePlayerMoney ( mechanic, 150 )
				setVehicleDamageProof ( vehicle, false )
				outputChatBox("Your vehicle wheels are repaired for $150 by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
				outputChatBox("".. getPlayerName(source) .." bought new wheels for his vehicle, you earned $150", mechanic, 0, 225, 0)
			else
				outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
			end
		end
	else
		outputChatBox("You're vehicle wheels are not broken, repair not needed", source, 225, 0, 0)
	end
	elseif (option == "option3") then
		if (getElementHealth(vehicle) < 999) then
			local vehicleFixPrice = math.floor(1000-getElementHealth(vehicle))
			if ( source == mechanic ) then
				local moneySaving = ( 60 / 100 * vehicleFixPrice )
				local totalPrice = ( vehicleFixPrice - moneySaving )
					if getPlayerMoney(source) > totalPrice then
						fixVehicle ( vehicle )
						local rx, ry, rz = getVehicleRotation ( vehicle )
							if ( rx > 110 ) and ( rx < 250 ) then
							local x, y, z = getElementPosition ( vehicle )
							setVehicleRotation ( vehicle, rx + 180, ry, rz )
							setElementPosition ( vehicle, x, y, z + 2 )
						end
						setElementFrozen ( vehicle, false )
						setVehicleDamageProof ( vehicle, false )
						takePlayerMoney ( source, math.floor(totalPrice) )
						outputChatBox("You repaired your vehicle, you paid 60% of the price. ($".. math.floor(totalPrice) ..")", source, 0, 225, 0)
					else
						outputChatBox("You don't have enough money for this", source, 225, 0, 0, 0)
					end
			else
				if getPlayerMoney(source) > vehicleFixPrice then
					fixVehicle ( vehicle )
					local rx, ry, rz = getVehicleRotation ( vehicle )
						if ( rx > 110 ) and ( rx < 250 ) then
						local x, y, z = getElementPosition ( vehicle )
						setVehicleRotation ( vehicle, rx + 180, ry, rz )
						setElementPosition ( vehicle, x, y, z + 2 )
					end
					setElementFrozen ( vehicle, false )
					takePlayerMoney ( source, vehicleFixPrice )
					givePlayerMoney ( mechanic, vehicleFixPrice )
					setVehicleDamageProof ( vehicle, false )
					outputChatBox("Your vehicle is repaired for $".. vehicleFixPrice .." by " .. getPlayerName ( mechanic ) .. "", source, 0, 225, 0)
					outputChatBox("You repaired ".. getPlayerName(source) .."'s vehicle, you earned $".. vehicleFixPrice .."", mechanic, 0, 225, 0)
				else
					outputChatBox("You don't have enough money for this", source, 225, 0, 0)
				end
			end
		else
			outputChatBox("This vehicle doesn't need a repair!", mechanic, 225, 0, 0)
		end
	end
end
addEvent("doVehicleRepair", true)
addEventHandler("doVehicleRepair", root, doVehicleRepair)